#!/bin/bash
if [ ! -d work ] ; then
vlib work
fi

if [ ! -f .synopsys_dc.setup ] ; then
mv synopsys_dc.setup .synopsys_dc.setup
fi

if [[ -s GCD.sv ]]; then
echo "*********************************** vlog GCD.sv tbskeleton.sv ***********************************"
vlog GCD.sv tbskeleton.sv
fi

if [ -s vsim.do ] ; then
echo "*********************************** vsim tb -novopt -do vsim.do -wlf GCD_RTL.wlf -quiet -c ***********************************"
vsim tb -novopt -do vsim.do -wlf GCD_RTL.wlf -quiet -c
fi
