#!/bin/bash
cd Glitch/

chmod 700 bash.sh
./bash.sh

cd ..
cd no_glitch/

chmod 700 bash.sh
./bash.sh
